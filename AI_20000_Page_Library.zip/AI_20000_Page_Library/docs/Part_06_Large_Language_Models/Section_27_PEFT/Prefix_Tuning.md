# Prefix Tuning

Part: Part 06 Large Language Models
Section: Parameter Efficient Fine Tuning

## Introduction

