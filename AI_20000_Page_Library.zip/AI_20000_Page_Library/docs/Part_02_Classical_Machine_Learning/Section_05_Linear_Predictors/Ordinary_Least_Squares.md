# Ordinary Least Squares

Part: Part 02 Classical Machine Learning
Section: Linear & Logistic Regression

## Introduction

