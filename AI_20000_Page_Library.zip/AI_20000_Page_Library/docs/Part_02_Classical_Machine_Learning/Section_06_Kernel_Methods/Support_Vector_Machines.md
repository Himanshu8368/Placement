# Support Vector Machines

Part: Part 02 Classical Machine Learning
Section: Distance & Kernel Methods

## Introduction

