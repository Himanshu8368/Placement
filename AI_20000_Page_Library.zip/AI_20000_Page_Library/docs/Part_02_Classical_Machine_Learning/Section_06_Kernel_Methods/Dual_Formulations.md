# Dual Formulations

Part: Part 02 Classical Machine Learning
Section: Distance & Kernel Methods

## Introduction

