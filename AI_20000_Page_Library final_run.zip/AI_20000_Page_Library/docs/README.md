# AI & Machine Learning Compendium

Welcome to the **AI & Machine Learning Compendium** - a comprehensive 20,000-page reference covering all aspects of Artificial Intelligence and Machine Learning.

## 📚 Quick Navigation

### Part 01: Mathematics for AI
- [Section 01: Linear Algebra](Part_01_Mathematics_for_AI/Section_01_Linear_Algebra/Vector_Spaces_and_Subspaces.md)
- [Section 02: Calculus](Part_01_Mathematics_for_AI/Section_02_Calculus/Gradients_and_Jacobians.md)
- [Section 03: Optimization](Part_01_Mathematics_for_AI/Section_03_Optimization/Stochastic_Gradient_Descent.md)
- [Section 04: Probability and Information](Part_01_Mathematics_for_AI/Section_04_Probability_and_Information/Information_Entropy.md)

### Part 02: Classical Machine Learning
- [Section 05: Linear Predictors](Part_02_Classical_Machine_Learning/Section_05_Linear_Predictors/3_Ordinary_Least_Squares.md)
- [Section 06: Kernel Methods](Part_02_Classical_Machine_Learning/Section_06_Kernel_Methods/05_Kernel_Functions.md)
- [Section 07: Tree Models](Part_02_Classical_Machine_Learning/Section_07_Tree_Models/Decision_Trees.md)
- [Section 08: Ensembles](Part_02_Classical_Machine_Learning/Section_08_Ensembles/AdaBoost.md)
- [Section 09: Unsupervised](Part_02_Classical_Machine_Learning/Section_09_Unsupervised/K_Means_Clustering.md)

### Part 03: Deep Learning Fundamentals
- [Section 10: MLP](Part_03_Deep_Learning_Fundamentals/Section_10_MLP/Forward_Propagation.md)
- [Section 11: Initialization Norm](Part_03_Deep_Learning_Fundamentals/Section_11_Initialization_Norm/Xavier_and_He_Init.md)
- [Section 12: Regularization](Part_03_Deep_Learning_Fundamentals/Section_12_Regularization/Dropout.md)

### Part 04: Computer Vision
- [Section 13: Convolutions](Part_04_Computer_Vision/Section_13_Convolutions/Convolutional_Kernels.md)
- [Section 14: CNN Architectures](Part_04_Computer_Vision/Section_14_CNN_Architectures/VGG_and_ResNet.md)
- [Section 15: Vision Transformers](Part_04_Computer_Vision/Section_15_Vision_Transformers/Patch_Embeddings.md)
- [Section 16: Object Detection](Part_04_Computer_Vision/Section_16_Object_Detection/R_CNN_Series.md)
- [Section 17: Image Segmentation](Part_04_Computer_Vision/Section_17_Image_Segmentation/Semantic_vs_Instance.md)
- [Section 18: Video Understanding](Part_04_Computer_Vision/Section_18_Video_Understanding/Temporal_Convolutions.md)
- [Section 19: Diffusion Models](Part_04_Computer_Vision/Section_19_Diffusion_Models/DDPM_Math.md)

### Part 05: Natural Language Processing
- [Section 20: Text Representation](Part_05_Natural_Language_Processing/Section_20_Text_Representation/Tokenization_Methods.md)
- [Section 21: Sequence Modeling](Part_05_Natural_Language_Processing/Section_21_Sequence_Modeling/RNN_Architecture.md)
- [Section 22: Transformer Architecture](Part_05_Natural_Language_Processing/Section_22_Transformer_Architecture/Self_Attention.md)
- [Section 23: Encoder Models](Part_05_Natural_Language_Processing/Section_23_Encoder_Models/BERT_Training_Objectives.md)
- [Section 24: Decoder Models](Part_05_Natural_Language_Processing/Section_24_Decoder_Models/Autoregressive_Language_Modeling.md)

### Part 06: Large Language Models
- [Section 25: Pretraining](Part_06_Large_Language_Models/Section_25_Pretraining/Data_Curation_and_Filtering.md)
- [Section 26: Fine Tuning Alignment](Part_06_Large_Language_Models/Section_26_Fine_Tuning_Alignment/Instruction_Fine_Tuning.md)
- [Section 27: PEFT](Part_06_Large_Language_Models/Section_27_PEFT/Prompt_Tuning.md)
- [Section 28: Small Language Models](Part_06_Large_Language_Models/Section_28_Small_Language_Models/Distillation.md)
- [Section 29: RAG](Part_06_Large_Language_Models/Section_29_RAG/Dense_Retrieval.md)

### Part 07: Reinforcement Learning
- [Section 30: RL Fundamentals](Part_07_Reinforcement_Learning/Section_30_RL_Fundamentals/Markov_Decision_Processes.md)
- [Section 31: Deep RL](Part_07_Reinforcement_Learning/Section_31_Deep_RL/Deep_Q_Networks.md)
- [Section 32: Advanced RL](Part_07_Reinforcement_Learning/Section_32_Advanced_RL/Model_Based_RL.md)
- [Section 33: Multi Agent RL](Part_07_Reinforcement_Learning/Section_33_Multi_Agent_RL/Game_Theory_Basics.md)
- [Section 34: Agents](Part_07_Reinforcement_Learning/Section_34_Agents/ReAct_Framework.md)
- [Section 35: Planning](Part_07_Reinforcement_Learning/Section_35_Planning/Search_Algorithms.md)

### Part 08: Robotics and Ethics
- [Section 36: Robotics](Part_08_Robotics_and_Ethics/Section_36_Robotics/Robot_Kinematics.md)
- [Section 37: AI Safety](Part_08_Robotics_and_Ethics/Section_37_AI_Safety/Value_Alignment.md)
- [Section 38: Ethics Governance](Part_08_Robotics_and_Ethics/Section_38_Ethics_Governance/Algorithmic_Accountability.md)
- [Section 45: AI Safety Trust](Part_08_Robotics_and_Ethics/Section_45_AI_Safety_Trust/Adversarial_Defense.md)
- [Section 53: Ethics Bias](Part_08_Robotics_and_Ethics/Section_53_Ethics_Bias/Deepfakes_and_Truth.md)

### Part 09: MLOps and Systems
- [Section 39: MLOps](Part_09_MLOps_and_Systems/Section_39_MLOps/Experiment_Tracking.md)
- [Section 40: Systems Infrastructure](Part_09_MLOps_and_Systems/Section_40_Systems_Infrastructure/Distributed_Data_Parallel.md)
- [Section 41: Data Centric AI](Part_09_MLOps_and_Systems/Section_41_Data_Centric_AI/Active_Learning.md)
- [Section 50: Federated Learning](Part_09_MLOps_and_Systems/Section_50_Federated_Learning/Federated_Averaging.md)

### Part 10: Specialized AI
- [Section 42: Audio Speech](Part_10_Specialized_AI/Section_42_Audio_Speech/Acoustic_Features.md)
- [Section 43: Document AI](Part_10_Specialized_AI/Section_43_Document_AI/OCR_and_Layout_Analysis.md)
- [Section 44: Multimodal](Part_10_Specialized_AI/Section_44_Multimodal/Contrastive_Learning.md)
- [Section 48: Graph ML](Part_10_Specialized_AI/Section_48_Graph_ML/Node_Classification.md)
- [Section 49: Time Series](Part_10_Specialized_AI/Section_49_Time_Series/Statistical_Forecasting.md)

### Part 11: AI Strategy and Future
- [Section 46: Future AI](Part_11_AI_Strategy_and_Future/Section_46_Future_AI/Quantum_Machine_Learning.md)
- [Section 47: Prompt Engineering](Part_11_AI_Strategy_and_Future/Section_47_Prompt_Engineering/Few_Shot_Prompting.md)
- [Section 51: Product Strategy](Part_11_AI_Strategy_and_Future/Section_51_Product_Strategy/AI_Product_Market_Fit.md)
- [Section 52: Domain Applications](Part_11_AI_Strategy_and_Future/Section_52_Domain_Applications/AI_in_Healthcare.md)

## 🔍 Features

### Core Features
- **Full-text search** across all 20,000 pages
- **Hierarchical navigation** - Browse by Part → Section → Chapter
- **MathJax support** for mathematical equations
- **Mobile-responsive** design
- **Dark/Light mode** toggle
- **PDF viewer** - Embedded PDF viewing with download options

### Reading Enhancements
- **Reading progress bar** - Track your reading position
- **Reading time estimates** - Know how long each article takes
- **Reading history** - See your recently read pages (last 3 on homepage)
- **Bookmarking system** - Save favorite pages for quick access

### Navigation & Discovery
- **Related pages suggestions** - Discover related content automatically
- **Glossary popup system** - Hover over terms to see definitions (50+ terms)
- **Keyboard shortcuts** - Press `?` to see all shortcuts
- **Enhanced navigation** - Breadcrumbs, table of contents, tracking

### Content Features
- **Print-friendly pages** - Optimized for printing and PDF export
- **Enhanced typography** - Better readability and spacing
- **Code block enhancements** - Copy buttons, syntax highlighting
- **Interactive elements** - Tooltips, smooth animations

### File Viewing Support
- **PDF Files** (.pdf) - Embedded PDF viewer with download
- **Text Files** (.txt) - Readable text display with copy option
- **PowerPoint** (.ppt, .pptx) - Online viewer for presentations
- **Word Documents** (.doc, .docx) - Online viewer for documents
- **Excel Files** (.xls, .xlsx) - Online viewer for spreadsheets

## 📖 How to Use

1. **Browse by Part**: Use the navigation menu on the left to explore all 11 parts
2. **Search**: Use the search bar at the top to find specific topics (or press `/`)
3. **Direct Links**: Click any section link above to jump directly to that content
4. **Bookmark Pages**: Click the bookmark button to save pages for later
5. **View Related Content**: Scroll to the bottom of any article to see related pages
6. **Learn Terms**: Hover over highlighted terms to see glossary definitions
7. **Track Progress**: See your reading history on the homepage
8. **Keyboard Shortcuts**: Press `?` to see all available shortcuts

## 🛠️ Technical Details

This compendium is built with:
- **MkDocs** - Static site generator
- **Material Theme** - Modern, responsive design
- **Markdown** - All content in markdown format

---

*Last updated: 2024*
